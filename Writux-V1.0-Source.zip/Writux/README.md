# Writux V1.0 - Floating AI Writing Assistant

A native Android app that shows a floating AI icon while you type. Tap to refine/grammar-fix text, double-tap for style options (casual, formal, witty, spicy, unhinged, etc.). Powered by DeepSeek via Token Harbor free API.

## Features
- Floating, draggable icon that appears when a text field is focused
- Single tap: Default refine / grammar fix
- Double tap: Style menu (Rephrase, Casual, Formal, Witty, Creative, Direct, Spicy, Unhinged, Bold, Friendly, Manipulative, Sarcastic, Critic, Cruel, Pursuing, Settings)
- Long press: Remove the floating icon
- Smart context: Reads the current text (or selection) and replaces it with AI output
- Full settings: API key, system prompt, temperature, model selection
- Uses Token Harbor free models (deepseek-v4.1-flash:free etc.)

## Setup
1. Sign up for free at https://tokenharbor.ai and create an API key (starts with `thk_live_`)
2. Open this project in **Android Studio**
3. Sync Gradle and build the APK (Build > Build Bundle(s)/APK(s) > Build APK(s))
4. Install the APK on your Android phone
5. Open the app, enter your API key, save
6. Enable the **Writux Accessibility Service** in Settings > Accessibility
7. Grant Overlay permission if prompted
8. Open any app (WhatsApp, Notes, browser, etc.) and start typing — the floating icon appears

## Requirements
- Android 8.0+ (API 26+)
- Internet connection
- Free Token Harbor API key

## Notes
- The app uses Accessibility Service to detect text fields and overlay the icon (TYPE_ACCESSIBILITY_OVERLAY).
- Text replacement uses ACTION_SET_TEXT with clipboard paste fallback.
- All processing happens via the Token Harbor OpenAI-compatible endpoint.
- Default model: `deepseek-v4.1-flash:free`

Enjoy smarter writing on the go!
