package com.writux.app

import android.accessibilityservice.AccessibilityService
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class WrituxAccessibilityService : AccessibilityService() {

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var popupView: View? = null
    private var isOverlayShown = false
    private var currentFocusedNode: AccessibilityNodeInfo? = null
    private val handler = Handler(Looper.getMainLooper())
    private var lastTapTime = 0L
    private val doubleTapTimeout = 300L

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private val styles = listOf(
        "Refine" to "Fix grammar, improve clarity, refine the text while keeping original meaning. Return only the improved text.",
        "Rephrase" to "Rephrase the text in a different way while preserving the core meaning. Return only the rephrased text.",
        "Casual" to "Rewrite the text in a casual, conversational, relaxed tone. Return only the rewritten text.",
        "Formal" to "Rewrite the text in a formal, professional, polished tone. Return only the rewritten text.",
        "Witty" to "Rewrite the text to be witty, clever, and humorous. Return only the rewritten text.",
        "Creative" to "Rewrite the text to be more creative, engaging, and vivid. Return only the rewritten text.",
        "Direct" to "Rewrite the text to be more direct, concise, and to the point. Return only the rewritten text.",
        "Spicy" to "Rewrite the text to be spicy, bold, slightly provocative, and full of energy. Return only the rewritten text.",
        "Unhinged" to "Rewrite the text to be unhinged, wild, over-the-top, and chaotic in a fun way. Return only the rewritten text.",
        "Bold" to "Rewrite the text to be bold, assertive, and confident. Return only the rewritten text.",
        "Friendly" to "Rewrite the text to be warm, friendly, and approachable. Return only the rewritten text.",
        "Manipulative" to "Rewrite the text to be subtly persuasive and manipulative while sounding natural. Return only the rewritten text.",
        "Sarcastic" to "Rewrite the text with a sarcastic, ironic tone. Return only the rewritten text.",
        "Critic" to "Critically analyze the text and provide a refined, improved version with constructive edge. Return only the improved text.",
        "Cruel" to "Rewrite the text to be cruel, harsh, and cutting (in a fictional/roleplay context). Return only the rewritten text.",
        "Pursuing" to "Rewrite the text to be more pursuing, persuasive, and goal-oriented. Return only the rewritten text.",
        "Settings" to ""
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val node = findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node != null && (node.isEditable || node.className?.contains("EditText") == true || node.className?.contains("TextView") == true && node.isEditable)) {
            currentFocusedNode = node
            if (!isOverlayShown) {
                showOverlay()
            }
        } else {
            // Optionally hide when not typing, but keep for now or hide after delay
            // For responsiveness, hide when no input focus
            hideOverlay()
        }
    }

    override fun onInterrupt() {}

    private fun showOverlay() {
        if (isOverlayShown) return
        handler.post {
            try {
                val inflater = LayoutInflater.from(this)
                overlayView = inflater.inflate(R.layout.overlay_icon, null)

                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                )
                params.gravity = Gravity.TOP or Gravity.START
                params.x = 100
                params.y = 300

                val icon = overlayView!!.findViewById<View>(R.id.floatingIcon)
                setupIconTouch(icon, params)

                windowManager.addView(overlayView, params)
                isOverlayShown = true
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun hideOverlay() {
        if (!isOverlayShown) return
        handler.post {
            try {
                overlayView?.let { windowManager.removeView(it) }
                popupView?.let { windowManager.removeView(it) }
                overlayView = null
                popupView = null
                isOverlayShown = false
            } catch (e: Exception) {}
        }
    }

    private fun setupIconTouch(icon: View, params: WindowManager.LayoutParams) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        icon.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) isDragging = true
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        val now = System.currentTimeMillis()
                        if (now - lastTapTime < doubleTapTimeout) {
                            // Double tap
                            showStylesPopup(params)
                            lastTapTime = 0
                        } else {
                            lastTapTime = now
                            handler.postDelayed({
                                if (lastTapTime == now) {
                                    // Single tap
                                    performDefaultRefine()
                                }
                            }, doubleTapTimeout)
                        }
                    }
                    true
                }
                else -> false
            }
        }

        icon.setOnLongClickListener {
            showDeleteOption(params)
            true
        }
    }

    private fun showDeleteOption(params: WindowManager.LayoutParams) {
        Toast.makeText(this, "Long press again to remove icon (or restart service)", Toast.LENGTH_SHORT).show()
        // Simple: long press removes
        hideOverlay()
    }

    private fun showStylesPopup(iconParams: WindowManager.LayoutParams) {
        handler.post {
            try {
                popupView?.let { windowManager.removeView(it) }
                val inflater = LayoutInflater.from(this)
                popupView = inflater.inflate(R.layout.styles_popup, null)
                val container = popupView!!.findViewById<LinearLayout>(R.id.stylesContainer)

                styles.forEach { (name, prompt) ->
                    val btn = Button(this).apply {
                        text = name
                        setOnClickListener {
                            if (name == "Settings") {
                                // Open main activity
                                val intent = Intent(this@WrituxAccessibilityService, MainActivity::class.java)
                                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                startActivity(intent)
                            } else {
                                performStyle(prompt)
                            }
                            try { windowManager.removeView(popupView) } catch (e: Exception) {}
                            popupView = null
                        }
                    }
                    container.addView(btn)
                }

                val popupParams = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
                )
                popupParams.gravity = Gravity.TOP or Gravity.START
                popupParams.x = iconParams.x + 80
                popupParams.y = iconParams.y

                windowManager.addView(popupView, popupParams)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun performDefaultRefine() {
        val prefs = getSharedPreferences("writux_prefs", MODE_PRIVATE)
        val systemPrompt = prefs.getString("system_prompt", "You are a helpful writing assistant. Fix grammar, improve clarity and flow, refine the text while preserving the original meaning and intent. Return only the improved text.")
        performStyle(systemPrompt ?: "")
    }

    private fun performStyle(stylePrompt: String) {
        val node = currentFocusedNode ?: findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: run {
            Toast.makeText(this, "No text field focused", Toast.LENGTH_SHORT).show()
            return
        }

        val text = node.text?.toString() ?: ""
        if (text.isBlank()) {
            Toast.makeText(this, "No text to refine", Toast.LENGTH_SHORT).show()
            return
        }

        val selectionStart = node.textSelectionStart
        val selectionEnd = node.textSelectionEnd
        val targetText = if (selectionStart >= 0 && selectionEnd > selectionStart) {
            text.substring(selectionStart, selectionEnd)
        } else text

        Toast.makeText(this, "Thinking...", Toast.LENGTH_SHORT).show()

        callApi(targetText, stylePrompt) { result ->
            handler.post {
                if (result != null) {
                    val newFullText = if (selectionStart >= 0 && selectionEnd > selectionStart) {
                        text.substring(0, selectionStart) + result + text.substring(selectionEnd)
                    } else result

                    val args = Bundle()
                    args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newFullText)
                    val success = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                    if (!success) {
                        // Fallback clipboard
                        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Writux", newFullText))
                        node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                        Toast.makeText(this, "Pasted via clipboard (set text failed)", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Text updated!", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this, "API error. Check key and internet.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun callApi(userText: String, systemPrompt: String, callback: (String?) -> Unit) {
        val prefs = getSharedPreferences("writux_prefs", MODE_PRIVATE)
        val apiKey = prefs.getString("api_key", "") ?: ""
        val model = prefs.getString("model", "deepseek-v4.1-flash:free") ?: "deepseek-v4.1-flash:free"
        val temperature = prefs.getFloat("temperature", 0.7f)

        if (apiKey.isBlank()) {
            handler.post { Toast.makeText(this, "Please set API key in Writux app", Toast.LENGTH_LONG).show() }
            callback(null)
            return
        }

        val messages = JSONArray().apply {
            put(JSONObject().put("role", "system").put("content", systemPrompt))
            put(JSONObject().put("role", "user").put("content", "Text to process:\n\n$userText"))
        }

        val bodyJson = JSONObject().apply {
            put("model", model)
            put("messages", messages)
            put("temperature", temperature)
            put("max_tokens", 2048)
        }

        val body = bodyJson.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url("https://tokenharbor.ai/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                callback(null)
            }

            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (!it.isSuccessful) {
                        callback(null)
                        return
                    }
                    val responseBody = it.body?.string() ?: return
                    try {
                        val json = JSONObject(responseBody)
                        val content = json.getJSONArray("choices")
                            .getJSONObject(0)
                            .getJSONObject("message")
                            .getString("content")
                            .trim()
                        callback(content)
                    } catch (e: Exception) {
                        callback(null)
                    }
                }
            }
        })
    }

    override fun onDestroy() {
        hideOverlay()
        super.onDestroy()
    }
}
