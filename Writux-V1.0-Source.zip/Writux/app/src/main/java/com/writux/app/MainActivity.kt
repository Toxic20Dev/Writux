package com.writux.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {

    private lateinit var apiKeyInput: TextInputEditText
    private lateinit var systemPromptInput: EditText
    private lateinit var temperatureSeek: SeekBar
    private lateinit var temperatureValue: TextView
    private lateinit var modelSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        apiKeyInput = findViewById(R.id.apiKeyInput)
        systemPromptInput = findViewById(R.id.systemPromptInput)
        temperatureSeek = findViewById(R.id.temperatureSeek)
        temperatureValue = findViewById(R.id.temperatureValue)
        modelSpinner = findViewById(R.id.modelSpinner)

        val models = arrayOf(
            "deepseek-v4.1-flash:free",
            "deepseek-v4-flash:free",
            "mimo-v2.6-flash:free",
            "mimo-v2.5:free"
        )
        modelSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, models)

        loadSettings()

        temperatureSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                temperatureValue.text = String.format("%.2f", progress / 100.0)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        findViewById<Button>(R.id.saveSettingsBtn).setOnClickListener {
            saveSettings()
            Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.enableAccessibilityBtn).setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "Enable Writux in Accessibility services", Toast.LENGTH_LONG).show()
        }

        findViewById<Button>(R.id.overlayPermissionBtn).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(intent)
            } else {
                Toast.makeText(this, "Overlay permission already granted", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadSettings() {
        val prefs = getSharedPreferences("writux_prefs", MODE_PRIVATE)
        apiKeyInput.setText(prefs.getString("api_key", ""))
        systemPromptInput.setText(prefs.getString("system_prompt", "You are a helpful writing assistant. Fix grammar, improve clarity and flow, refine the text while preserving the original meaning and intent. Return only the improved text."))
        val temp = prefs.getFloat("temperature", 0.7f)
        temperatureSeek.progress = (temp * 100).toInt()
        temperatureValue.text = String.format("%.2f", temp)
        val model = prefs.getString("model", "deepseek-v4.1-flash:free")
        val adapter = modelSpinner.adapter as ArrayAdapter<*>
        val pos = (0 until adapter.count).firstOrNull { adapter.getItem(it) == model } ?: 0
        modelSpinner.setSelection(pos)
    }

    private fun saveSettings() {
        val prefs = getSharedPreferences("writux_prefs", MODE_PRIVATE)
        prefs.edit().apply {
            putString("api_key", apiKeyInput.text.toString().trim())
            putString("system_prompt", systemPromptInput.text.toString())
            putFloat("temperature", temperatureSeek.progress / 100.0f)
            putString("model", modelSpinner.selectedItem.toString())
            apply()
        }
    }
}
